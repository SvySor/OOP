package org.example.sem3;

import java.util.List;

public class RuGame extends AbstractGame {
    @Override
    List<String> generateCharList() {

    }
}
