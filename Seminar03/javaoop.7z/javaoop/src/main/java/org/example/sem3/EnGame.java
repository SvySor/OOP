package org.example.sem3;

import java.util.List;

public class EnGame extends AbstractGame{
    @Override
    List<String> generateCharList() {

    }
}
