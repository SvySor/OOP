package org.example.sem3;

public enum GameStatus {
    WIN,LOSE,START,INIT;
}
