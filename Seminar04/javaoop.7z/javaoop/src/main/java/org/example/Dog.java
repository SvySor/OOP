package org.example;

public class Dog extends Animal {
    @Override
    public void voice() {
        System.out.println("gav-gav");
    }
}
